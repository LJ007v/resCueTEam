import os

# 请在这里配置你的 API Key
os.environ["OPENAI_API_KEY"] = "sk-xxxxxxxxxxxxxxxx" 
# 如果是阿里云 DashScope，记得设置 base_url
# os.environ["OPENAI_API_BASE"] = "https://dashscope.aliyuncs.com/compatible-mode/v1"

from spark_autotuner import SparkAutoTuner

def main():
    print("🚀 正在初始化 Spark Auto-Tuner 包...")
    
    # 实例化 Agent
    tuner = SparkAutoTuner()
    
    # 模拟用户查询
    user_query = "请帮我统计 2023-10-24 这一天，行为类型为 'pv' 的用户 Top 10。"
    
    print(f"\n📝 用户输入: {user_query}")
    print("-" * 30)
    
    # 运行 Agent
    try:
        result_sql = tuner.run(user_query)
        print("-" * 30)
        print("\n✅ Agent 生成的最终 SQL:")
        print(result_sql)
    except Exception as e:
        print(f"❌ 错误: {e}")

if __name__ == "__main__":
    main()
