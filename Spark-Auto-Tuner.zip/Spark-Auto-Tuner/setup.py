from setuptools import setup, find_packages

setup(
    name="spark_autotuner",
    version="0.1.0",
    author="AtomCode User",
    description="An AI-powered Agent for Spark SQL Auto-Tuning",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "langchain>=0.1.0",
        "langchain-openai>=0.0.5",
        "langchain-core>=0.1.0",
        "pydantic>=1.10.0",
    ],
)
