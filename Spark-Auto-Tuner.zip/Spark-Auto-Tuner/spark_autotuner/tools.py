from langchain_core.tools import tool

@tool
def get_table_schema(table_name: str) -> str:
    """获取数据表的字段和分区信息"""
    return """
    Table: user_behavior
    Columns: [user_id: STRING, item_id: STRING, category_id: STRING, behavior_type: STRING, ts: BIGINT]
    Partition: [dt: STRING]
    """

@tool
def get_explain_plan(sql: str) -> str:
    """获取 SQL 执行计划，分析性能瓶颈"""
    # 模拟返回一个包含性能警告的执行计划
    return """
    [Explain Plan Output]
    1. Scan on user_behavior (Type: Full Table Scan) -> ⚠️ Warning: No partition filter detected.
    2. Filter (behavior_type = 'pv')
    3. GroupBy (user_id)
    
    Recommendation: Add WHERE dt = '...' to enable partition pruning.
    """

@tool
def apply_optimization(current_sql: str) -> str:
    """根据诊断结果优化 SQL"""
    # 模拟优化后的结果
    optimized = "SELECT user_id, count(1) FROM user_behavior WHERE dt='2023-10-24' AND behavior_type='pv' GROUP BY user_id ORDER BY count(1) DESC LIMIT 10"
    return optimized
