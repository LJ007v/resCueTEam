import os
from typing import Optional
from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from .tools import get_table_schema, get_explain_plan, apply_optimization

class SparkAutoTuner:
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        初始化 Spark Auto-Tuner Agent
        :param api_key: 你的大模型 API Key (默认读取环境变量 OPENAI_API_KEY)
        :param base_url: API 地址 (例如阿里云 DashScope)
        """
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.base_url = base_url or os.getenv("OPENAI_API_BASE")
        
        # 配置 LLM
        llm_kwargs = {"model": "gpt-4o-mini", "temperature": 0, "api_key": self.api_key}
        if self.base_url:
            llm_kwargs["base_url"] = self.base_url
            
        self.llm = ChatOpenAI(**llm_kwargs)
        self.tools = [get_table_schema, get_explain_plan, apply_optimization]
        
        # 核心 Prompt：引导长链推理
        self.system_prompt = """
        你是一个资深大数据研发专家。请帮助用户编写高效的 Spark SQL。
        执行逻辑（Chain of Thought）：
        1. 先用 get_table_schema 确认表结构。
        2. 生成初始 SQL。
        3. 【关键】使用 get_explain_plan 检查性能，重点排查全表扫描。
        4. 发现问题后，调用 apply_optimization 进行优化。
        5. 最终输出优化后的 SQL 语句。
        """
        
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", self.system_prompt),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad")
        ])
        
        self.executor = AgentExecutor(
            agent=create_react_agent(self.llm, self.tools, self.prompt),
            tools=self.tools,
            verbose=True
        )

    def run(self, query: str) -> str:
        """运行调优流程并返回最终 SQL"""
        result = self.executor.invoke({"input": query})
        return result["output"]
